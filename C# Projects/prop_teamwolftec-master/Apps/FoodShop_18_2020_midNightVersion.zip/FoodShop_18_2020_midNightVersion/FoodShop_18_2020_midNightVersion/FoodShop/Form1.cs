﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data;
using MySql.Data.MySqlClient;
using Phidget22;
using Phidget22.Events;

namespace FoodShop
{
    public partial class Form1 : Form
    {
        RFID rfid;
        Mysql mysql;
        string rfid_Code = "";
        int totalPrice = 0;
        // souvenirs
        int tShirt_Quantity = 0;
        int keyChainQuantity = 0;
        int Caps_Quantity = 0;

        // drinks

        int wijn_Quantity = 0;
        int drinks_Quantity = 0;
        int beer_Quantity = 0;

        // foods
        int burger_Quantity = 0;
        int toaste_Quantity = 0;
        int ice_Cream_Quantity = 0;
      
     
        public Form1()
        {
            InitializeComponent();
            // timer and rfid
            mysql = new Mysql();
            timer1.Start();

            // souvenirs
            lbKeyChainPrice.Text = "";
            lbIce_CreamPrice.Text = "";
            lbTshirtPrice.Text = "";

            // drinks

            lbBeerPrice.Text = "";
            lbWijnPrice.Text = "";
            lbDrinksPrice.Text = "";
           
          
           // foods
            lbBurgerPrice.Text = "";        
            lbToastePrice.Text = "";
            lbIce_CreamPrice.Text = "";
            
           
            pbIceCream.Hide();
            pbBurger.Hide();
            pbToaste.Hide();
            pbBeer.Hide();
            pbWijn.Hide();
            pbSoftDrinks.Hide();
            btnKeyChain.Hide();
            btnTShirt.Hide();
            btnCaps.Hide();
            gbDrinks.Hide();
            gbSouvenirs.Hide();
            gbFood.Visible = true;
        }

        private void btnSouvenirs_Click(object sender, EventArgs e)
        {
            btnFood.BackgroundImage = Properties.Resources.button_food_bank__1_;
            btnSouvenirs.BackgroundImage = Properties.Resources.button_souvenirs__2_;
            btnDrinks.BackgroundImage = Properties.Resources.button_drinks__1_;

            btnFood.BackgroundImageLayout = ImageLayout.Stretch;
            btnSouvenirs.BackgroundImageLayout = ImageLayout.Stretch;
            btnDrinks.BackgroundImageLayout = ImageLayout.Stretch;

            gbDrinks.Hide();
            gbFood.Hide();
            gbSouvenirs.Show();
        }

        private void btnDrinks_Click(object sender, EventArgs e)
        {
            btnFood.BackgroundImage = Properties.Resources.button_food_bank__1_;
            btnSouvenirs.BackgroundImage = Properties.Resources.button_souvenirs__1_;
            btnDrinks.BackgroundImage = Properties.Resources.button_drinks__2_;

            btnFood.BackgroundImageLayout = ImageLayout.Stretch;
            btnSouvenirs.BackgroundImageLayout = ImageLayout.Stretch;
            btnDrinks.BackgroundImageLayout = ImageLayout.Stretch;

            gbFood.Hide();
            gbSouvenirs.Hide();
            gbDrinks.Show();
        }

        private void btnFood_Click(object sender, EventArgs e)
        {
            btnFood.BackgroundImage = Properties.Resources.button_food_bank__2_;
            btnSouvenirs.BackgroundImage = Properties.Resources.button_souvenirs__1_;
            btnDrinks.BackgroundImage = Properties.Resources.button_drinks__1_;

            btnFood.BackgroundImageLayout = ImageLayout.Stretch;
            btnSouvenirs.BackgroundImageLayout = ImageLayout.Stretch;
            btnDrinks.BackgroundImageLayout = ImageLayout.Stretch;

            gbDrinks.Hide();
            gbSouvenirs.Hide();
            gbFood.Show();
        }

        private void btnScan_Click(object sender, EventArgs e)
        {
            try
            {
                lbPurchaseStatus.Text = "";
                rfid = new RFID();

                rfid.Attach += new AttachEventHandler(myRfidAttachMethod);
                rfid.Tag += new RFIDTagEventHandler(CheckUserRfid);

                rfid.Open();
            }
            catch (PhidgetException ex)
            {
                throw ex;
            }
        }
        public void myRfidAttachMethod(object sender, AttachEventArgs args)
        {
            lbVisitorName.Text = "Attached";
        }
        public void CheckUserRfid(object sender, RFIDTagEventArgs args)
        {
            rfid_Code = args.Tag;
            Mysql dh = new Mysql();
            string userName = dh.GetUserNameWithRfid(rfid_Code);
            
            if (userName != "")
            {
                lbVisitorName.Text = userName;
            }
            else
            {
                lbVisitorName.Text = rfid_Code;
            }
            rfid.Close();
        }

        private void Wonditimer1_Tick(object sender, EventArgs e)
        {
            tShirt_Quantity = mysql.GetSoldQuantity("T-Shirt");
            wijn_Quantity = mysql.GetSoldQuantity("Wijn");
            keyChainQuantity = mysql.GetSoldQuantity("Key_chain");
            burger_Quantity = mysql.GetSoldQuantity("Burger");
            toaste_Quantity = mysql.GetSoldQuantity("Toaste");
            ice_Cream_Quantity = mysql.GetSoldQuantity("Ice Cream");
            drinks_Quantity = mysql.GetSoldQuantity("SoftDrink");
            Caps_Quantity = mysql.GetSoldQuantity("Caps");
            beer_Quantity = mysql.GetSoldQuantity("Beer");

            lbBeerPrice.Text = mysql.GetItemPrice("Beer") + "€";
            lbBurgerPrice.Text = mysql.GetItemPrice("Burger") + "€";        
            lbCapsPrice.Text = mysql.GetItemPrice("Caps") + "€";
            lbDrinksPrice.Text = mysql.GetItemPrice("SoftDrink") + "€";
            lbKeyChainPrice.Text = mysql.GetItemPrice("Key_chain") + "€";
            lbWijnPrice.Text = mysql.GetItemPrice("Wijn") + "€";
            lbToastePrice.Text = mysql.GetItemPrice("Toaste") + "€";
            lbTshirtPrice.Text = mysql.GetItemPrice("T-Shirt") + "€";

            if (tShirt_Quantity < 1)
            {
                lbTShirtStockQuantity.Text = "Out of the stock";
            }
            else
            {
                lbTShirtStockQuantity.Text = tShirt_Quantity + " LEFT";
            }

            if (Caps_Quantity < 1)
            {
                lbCapsStockQuantity.Text = "Out of the stock";
            }
            else
            {
                lbCapsStockQuantity.Text = wijn_Quantity + " LEFT";
            }

            if (keyChainQuantity < 1)
            {
                lbKeyChainStockQuantity.Text = "Out of the stock";
            }
            else
            {
                lbKeyChainStockQuantity.Text = keyChainQuantity + " LEFT";
            }

            if (burger_Quantity < 1)
            {
                lbBurgerQunatity.Text = "Out of the stock";
            }
            else
            {
                lbBurgerQunatity.Text = burger_Quantity + " LEFT";
            }

            if (toaste_Quantity < 1)
            {
                lbToasteStockQuantity.Text = "Out of the stock";
            }
            else
            {
                lbToasteStockQuantity.Text = toaste_Quantity + " LEFT";
            }

            if (ice_Cream_Quantity < 1)
            {
                lbIscreamQuantity.Text = "Out of the stock";
            }
            else
            {
                lbIscreamQuantity.Text = ice_Cream_Quantity + " LEFT";
            }

            if (drinks_Quantity < 1)
            {
                
                lbDrinkQuantity.Text = "Out ofthe stock";
            }
            else
            {
                lbDrinkQuantity.Text = drinks_Quantity + " LEFT";
            }

            if (wijn_Quantity < 1)
            {
                lbWijnQuantity.Text = "Out of the stock";
            }
            else
            {
                lbWijnQuantity.Text = Caps_Quantity + " LEFT";
            }

            if (beer_Quantity < 1)
            {
                lbBeerQuantity.Text = "Out of the stock";
            }
            else
            {
                lbBeerQuantity.Text = beer_Quantity + " LEFT";
            }
            pbIceCream.Show();
            pbBurger.Show();
            pbToaste.Show();
            pbBeer.Show();
            pbWijn.Show();
            pbSoftDrinks.Show();
            btnKeyChain.Show();
            btnTShirt.Show();
            btnCaps.Show();
            timer1.Stop();
        }
        private int GetProductPrice(string product)
        {
            int end = product.LastIndexOf("€");
            int productPrice =Convert.ToInt32(product.Substring(0, end).TrimEnd());
            return productPrice;
        }
        private void pbIceCream_Click(object sender, EventArgs e)
        {
            if (ice_Cream_Quantity == 0)
            {
                lbPurchaseStatus.Text = "Sorry this item is out of stock !";
                lbPurchaseStatus.ForeColor = Color.Red;
            }
            else
            {
                List<string> temp = new List<string>();
                lbReceipt.Items.Add("Ice Cream - " + lbIce_CreamPrice.Text);
                foreach (string item in lbReceipt.Items)
                {
                    temp.Add(item);
                }
                temp.Sort();
                lbReceipt.Items.Clear();
                foreach (string item in temp)
                {
                    lbReceipt.Items.Add(item);
                }
                totalPrice += GetProductPrice(lbIce_CreamPrice.Text); ;
                lbTotalPrice.Text = totalPrice.ToString() + "€";
                ice_Cream_Quantity--;
                lbIscreamQuantity.Text = ice_Cream_Quantity + "LEFT";
            }
           
        }

        private void pbToaste_Click(object sender, EventArgs e)
        {
            if (toaste_Quantity == 0)
            {
                lbPurchaseStatus.Text = "Out of the stock";
                lbPurchaseStatus.ForeColor = Color.Red;
            }
            else
            {
                List<string> temp = new List<string>();
                lbReceipt.Items.Add("Toaste - " + lbToastePrice.Text);
                foreach (string item in lbReceipt.Items)
                {
                    temp.Add(item);
                }
                temp.Sort();
                lbReceipt.Items.Clear();
                foreach (string item in temp)
                {
                    lbReceipt.Items.Add(item);
                }
                totalPrice += GetProductPrice(lbToastePrice.Text); ;
                lbTotalPrice.Text = totalPrice.ToString() + "€";
                toaste_Quantity--;
                lbToasteStockQuantity.Text = toaste_Quantity + "LEFT";
            }
        }

        private void pbBurger_Click(object sender, EventArgs e)
        {
            if (burger_Quantity == 0)
            {
                lbPurchaseStatus.Text = "Out of the stock";
                lbPurchaseStatus.ForeColor = Color.Red;
            }
            else
            {
                List<string> temp = new List<string>();
                lbReceipt.Items.Add("Burger - " + lbBurgerPrice.Text);
                foreach (string item in lbReceipt.Items)
                {
                    temp.Add(item);
                }
                temp.Sort();
                lbReceipt.Items.Clear();
                foreach (string item in temp)
                {
                    lbReceipt.Items.Add(item);
                }
                totalPrice += GetProductPrice(lbBurgerPrice.Text); ;
                lbTotalPrice.Text = totalPrice.ToString() + "€";
                burger_Quantity--;
                lbBurgerQunatity.Text = burger_Quantity + "LEFT";
            }
        }

        private void btnTShirt_Click(object sender, EventArgs e)
        {
            if (tShirt_Quantity == 0)
            {
                lbPurchaseStatus.Text = "Out of the stock";
                lbPurchaseStatus.ForeColor = Color.Red;
            }
            else
            {
                List<string> temp = new List<string>();
                lbReceipt.Items.Add("T-Shirt - " + lbTshirtPrice.Text);
                foreach (string item in lbReceipt.Items)
                {
                    temp.Add(item);
                }
                temp.Sort();
                lbReceipt.Items.Clear();
                foreach (string item in temp)
                {
                    lbReceipt.Items.Add(item);
                }
                totalPrice += GetProductPrice(lbTshirtPrice.Text); ;
                lbTotalPrice.Text = totalPrice.ToString() + "€";
                tShirt_Quantity--;
                lbTShirtStockQuantity.Text = tShirt_Quantity + "LEFT";
            }
        }

        private void btnWijn_Click(object sender, EventArgs e)
        {
            if (wijn_Quantity == 0)
            {
                lbPurchaseStatus.Text = "Out of the stock";
                lbPurchaseStatus.ForeColor = Color.Red;
            }
            else
            {
                List<string> temp = new List<string>();
                lbReceipt.Items.Add("Wijn - "+ lbWijnPrice.Text);
                foreach (string item in lbReceipt.Items)
                {
                    temp.Add(item);
                }
                temp.Sort();
                lbReceipt.Items.Clear();
                foreach (string item in temp)
                {
                    lbReceipt.Items.Add(item);
                }
                totalPrice += GetProductPrice(lbWijnPrice.Text); ;
                lbTotalPrice.Text = totalPrice.ToString() + "€";
                wijn_Quantity--;
                lbWijnQuantity.Text = wijn_Quantity + "LEFT";
            }
        }

        private void btnKeyChain_Click(object sender, EventArgs e)
        {
            if (keyChainQuantity == 0)
            {
                lbPurchaseStatus.Text = "Out of the stock";
                lbPurchaseStatus.ForeColor = Color.Red;
            }
            else
            {
                List<string> temp = new List<string>();
                lbReceipt.Items.Add("Key-Chain - " + lbKeyChainPrice.Text);
                foreach (string item in lbReceipt.Items)
                {
                    temp.Add(item);
                }
                temp.Sort();
                lbReceipt.Items.Clear();
                foreach (string item in temp)
                {
                    lbReceipt.Items.Add(item);
                }
                totalPrice += GetProductPrice(lbKeyChainPrice.Text); ;
                lbTotalPrice.Text = totalPrice.ToString() + "€";
                keyChainQuantity--;
                lbKeyChainStockQuantity.Text = keyChainQuantity + "LEFT";
            }
        }

        private void pbBeer_Click(object sender, EventArgs e)
        {
            if (beer_Quantity == 0)
            {
                lbPurchaseStatus.Text = "Out of the stock";
                lbPurchaseStatus.ForeColor = Color.Red;
            }
            else
            {
                List<string> temp = new List<string>();
                lbReceipt.Items.Add("Beer - " + lbBeerPrice.Text);
                foreach (string item in lbReceipt.Items)
                {
                    temp.Add(item);
                }
                temp.Sort();
                lbReceipt.Items.Clear();
                foreach (string item in temp)
                {
                    lbReceipt.Items.Add(item);
                }
                totalPrice += GetProductPrice(lbBeerPrice.Text);
                lbTotalPrice.Text = totalPrice.ToString() + "€";
                beer_Quantity--;
                lbBeerQuantity.Text = beer_Quantity + "LEFT";
            }
        }

        private void pbDrinks_Click(object sender, EventArgs e)
        {
            if (drinks_Quantity == 0)
            {
                lbPurchaseStatus.Text = "Out of the stock";
                lbPurchaseStatus.ForeColor = Color.Red;
            }
            else
            {
                List<string> temp = new List<string>();
                lbReceipt.Items.Add("Soft Drink - " + lbDrinksPrice.Text);
                foreach (string item in lbReceipt.Items)
                {
                    temp.Add(item);
                }
                temp.Sort();
                lbReceipt.Items.Clear();
                foreach (string item in temp)
                {
                    lbReceipt.Items.Add(item);
                }
                totalPrice += GetProductPrice(lbDrinksPrice.Text);
                lbTotalPrice.Text = totalPrice.ToString() + "€";
                drinks_Quantity--;
                lbDrinkQuantity.Text = drinks_Quantity + "LEFT";
            }
        }

        private void pbXts_Click(object sender, EventArgs e)
        {
            //if (xtc_Quantity == 0)
            //{
            //    lbPurchaseStatus.Text = "Out of the stock";
            //    lbPurchaseStatus.ForeColor = Color.Red;
            //}
            //else
            //{
            //    List<string> temp = new List<string>();
            //    lbReceipt.Items.Add("Caps - " + lbWijnPrice.Text);
            //    foreach (string item in lbReceipt.Items)
            //    {
            //        temp.Add(item);
            //    }
            //    temp.Sort();
            //    lbReceipt.Items.Clear();
            //    foreach (string item in temp)
            //    {
            //        lbReceipt.Items.Add(item);
            //    }
            //    totalPrice += GetProductPrice(lbWijnPrice.Text);
            //    lbTotalPrice.Text = totalPrice.ToString() + "€";
            //    Caps_Quantity--;
            //    lbCapsStockQuantity.Text = Caps_Quantity + "LEFT";
            //}
        }

        private void btnSell_Click(object sender, EventArgs e)
        {

            List<string> itemsToSell = new List<string>();
            foreach (string item in lbReceipt.Items)
            {
                itemsToSell.Add(item);
            }

            string status = mysql.SellItemToClient(rfid_Code, itemsToSell, totalPrice);
            if (status == "added correctly")
            {
                lbPurchaseStatus.Text = "Successfully Sold!";
                lbPurchaseStatus.ForeColor = Color.Green;
            }
            else if (status == "there is no user ")
            {
                lbPurchaseStatus.Text = "There is no user with that RFID !";
                lbPurchaseStatus.ForeColor = Color.Red;
                List<string> items = new List<string>();
                foreach (string item in lbReceipt.Items)
                {
                    items.Add(item);
                }
                foreach (string item in items)
                {
                    lbReceipt.SelectedItem = item;
                    btnRemove.PerformClick();
                }
            }
            else if (status == "no money or balance")
            {
                lbPurchaseStatus.Text = "Not enough balance !";
                lbPurchaseStatus.ForeColor = Color.Red;
                List<string> items = new List<string>();
                foreach (string item in lbReceipt.Items)
                {
                    items.Add(item);
                }
                foreach (string item in items)
                {
                    lbReceipt.SelectedItem = item;
                    btnRemove.PerformClick();
                }
            }
            else
            {
                MessageBox.Show(status);
            }
            totalPrice = 0;
            lbTotalPrice.Text = totalPrice.ToString();
            lbReceipt.Items.Clear();
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            try
            {
                // caps
                if (lbReceipt.SelectedItem.ToString() == "Caps - " + lbCapsPrice.Text)
                {
                    lbReceipt.Items.Remove(lbReceipt.SelectedItem);
                    Caps_Quantity++;
                    lbCapsStockQuantity.Text = Caps_Quantity + "LEFT";
                    totalPrice -= GetProductPrice(lbCapsPrice.Text);
                    lbTotalPrice.Text = totalPrice.ToString() + "€";
                }
                // ice cream
                else if (lbReceipt.SelectedItem.ToString() == "Ice Cream - " + lbIce_CreamPrice.Text)
                {
                    lbReceipt.Items.Remove(lbReceipt.SelectedItem);
                    ice_Cream_Quantity++;
                    lbIscreamQuantity.Text = ice_Cream_Quantity + "LEFT";
                    totalPrice -= GetProductPrice(lbIce_CreamPrice.Text);
                    lbTotalPrice.Text = totalPrice.ToString() + "€";
                }
                // burger
                else if (lbReceipt.SelectedItem.ToString() == "Burger - " + lbBurgerPrice.Text)
                {
                    lbReceipt.Items.Remove(lbReceipt.SelectedItem);
                    burger_Quantity++;
                    lbBurgerQunatity.Text = burger_Quantity + "LEFT";
                    totalPrice -= GetProductPrice(lbBurgerPrice.Text);
                    lbTotalPrice.Text = totalPrice.ToString() + "€";
                }
                // beer
                else if (lbReceipt.SelectedItem.ToString() == "Beer - " + lbBeerPrice.Text)
                {
                    lbReceipt.Items.Remove(lbReceipt.SelectedItem);
                    beer_Quantity++;
                    lbBeerQuantity.Text = beer_Quantity + "LEFT";
                    totalPrice -= GetProductPrice(lbBeerPrice.Text);
                    lbTotalPrice.Text = totalPrice.ToString() + "€";
                }
                // t-shirt
                else if (lbReceipt.SelectedItem.ToString() == "T-Shirt - " + lbTshirtPrice.Text)
                {
                    lbReceipt.Items.Remove(lbReceipt.SelectedItem);
                    tShirt_Quantity++;
                    lbTShirtStockQuantity.Text = tShirt_Quantity + "LEFT";
                    totalPrice -= GetProductPrice(lbTshirtPrice.Text);
                    lbTotalPrice.Text = totalPrice.ToString() + "€";
                }
                // wijn
                else if (lbReceipt.SelectedItem.ToString() == "Wijn - " + lbWijnPrice.Text)
                {
                    lbReceipt.Items.Remove(lbReceipt.SelectedItem);
                    wijn_Quantity++;
                    lbWijnQuantity.Text = wijn_Quantity + "LEFT";
                    totalPrice -= GetProductPrice(lbWijnPrice.Text);
                    lbTotalPrice.Text = totalPrice.ToString() + "€";
                }
                // drinks
                else if (lbReceipt.SelectedItem.ToString() == "SoftDrink- " + lbDrinksPrice.Text)
                {
                    lbReceipt.Items.Remove(lbReceipt.SelectedItem);
                    drinks_Quantity++;
                    lbDrinkQuantity.Text = drinks_Quantity + "LEFT";
                    totalPrice -= GetProductPrice(lbDrinksPrice.Text);
                    lbTotalPrice.Text = totalPrice.ToString() + "€";
                }
                // keychain
                else if (lbReceipt.SelectedItem.ToString() == "Key_chain - " + lbKeyChainPrice.Text)
                {
                    lbReceipt.Items.Remove(lbReceipt.SelectedItem);
                    keyChainQuantity++;
                    lbKeyChainStockQuantity.Text = keyChainQuantity + "LEFT";
                    totalPrice -= GetProductPrice(lbKeyChainPrice.Text);
                    lbTotalPrice.Text = totalPrice.ToString() + "€";
                }
                // Toaste
                else if (lbReceipt.SelectedItem.ToString() == "Toaste - " + lbToastePrice.Text)
                {
                    lbReceipt.Items.Remove(lbReceipt.SelectedItem);
                    toaste_Quantity++;
                    lbToasteStockQuantity.Text = toaste_Quantity + "LEFT";
                    totalPrice -= GetProductPrice(lbToastePrice.Text);
                    lbTotalPrice.Text = totalPrice.ToString() + "€";
                }
            }
            catch (NullReferenceException)
            {
                lbPurchaseStatus.Text = "Please first select the item you want to remove !";
                lbPurchaseStatus.ForeColor = Color.Red;
            }
        }

        private bool dragging = false;
        private Point dragCursorPoint;
        private Point dragFormPoint;

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            dragging = true;
            dragCursorPoint = Cursor.Position;
            dragFormPoint = this.Location;
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            if (dragging)
            {
                Point dif = Point.Subtract(Cursor.Position, new Size(dragCursorPoint));
                this.Location = Point.Add(dragFormPoint, new Size(dif));
            }
        }

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            dragging = false;
        }

       
        public void HideCloseBtn()
        {
            this.btnClose.Hide();
        }

      
    }
}
