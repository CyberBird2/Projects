﻿namespace FoodShop
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.gbFood = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lbIscreamQuantity = new System.Windows.Forms.Label();
            this.lbToasteStockQuantity = new System.Windows.Forms.Label();
            this.lbBurgerQunatity = new System.Windows.Forms.Label();
            this.lbToastePrice = new System.Windows.Forms.Label();
            this.lbBurgerPrice = new System.Windows.Forms.Label();
            this.lbIce_CreamPrice = new System.Windows.Forms.Label();
            this.pbIceCream = new System.Windows.Forms.PictureBox();
            this.pbToaste = new System.Windows.Forms.PictureBox();
            this.pbBurger = new System.Windows.Forms.PictureBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.btnClose = new System.Windows.Forms.PictureBox();
            this.gbDrinks = new System.Windows.Forms.GroupBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lbWijnQuantity = new System.Windows.Forms.Label();
            this.lbDrinkQuantity = new System.Windows.Forms.Label();
            this.lbWijnPrice = new System.Windows.Forms.Label();
            this.lbDrinksPrice = new System.Windows.Forms.Label();
            this.lbBeerPrice = new System.Windows.Forms.Label();
            this.lbBeerQuantity = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pbWijn = new System.Windows.Forms.PictureBox();
            this.pbSoftDrinks = new System.Windows.Forms.PictureBox();
            this.pbBeer = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lbPurchaseStatus = new System.Windows.Forms.Label();
            this.lbVisitorName = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.lbTotalPrice = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.btnSell = new System.Windows.Forms.Button();
            this.btnRemove = new System.Windows.Forms.Button();
            this.lbReceipt = new System.Windows.Forms.ListBox();
            this.btnScan = new System.Windows.Forms.Button();
            this.gbSouvenirs = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lbKeyChainStockQuantity = new System.Windows.Forms.Label();
            this.lbCapsStockQuantity = new System.Windows.Forms.Label();
            this.lbKeyChainPrice = new System.Windows.Forms.Label();
            this.lbCapsPrice = new System.Windows.Forms.Label();
            this.lbTshirtPrice = new System.Windows.Forms.Label();
            this.lbTShirtStockQuantity = new System.Windows.Forms.Label();
            this.btnKeyChain = new System.Windows.Forms.Button();
            this.btnCaps = new System.Windows.Forms.Button();
            this.btnTShirt = new System.Windows.Forms.Button();
            this.btnSouvenirs = new System.Windows.Forms.Button();
            this.btnDrinks = new System.Windows.Forms.Button();
            this.btnFood = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.gbFood.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbIceCream)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbToaste)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbBurger)).BeginInit();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnClose)).BeginInit();
            this.gbDrinks.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbWijn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSoftDrinks)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbBeer)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.gbSouvenirs.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbFood
            // 
            this.gbFood.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.gbFood.Controls.Add(this.label6);
            this.gbFood.Controls.Add(this.label5);
            this.gbFood.Controls.Add(this.label4);
            this.gbFood.Controls.Add(this.lbIscreamQuantity);
            this.gbFood.Controls.Add(this.lbToasteStockQuantity);
            this.gbFood.Controls.Add(this.lbBurgerQunatity);
            this.gbFood.Controls.Add(this.lbToastePrice);
            this.gbFood.Controls.Add(this.lbBurgerPrice);
            this.gbFood.Controls.Add(this.lbIce_CreamPrice);
            this.gbFood.Controls.Add(this.pbIceCream);
            this.gbFood.Controls.Add(this.pbToaste);
            this.gbFood.Controls.Add(this.pbBurger);
            this.gbFood.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gbFood.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbFood.Location = new System.Drawing.Point(14, 191);
            this.gbFood.Margin = new System.Windows.Forms.Padding(4);
            this.gbFood.Name = "gbFood";
            this.gbFood.Padding = new System.Windows.Forms.Padding(4);
            this.gbFood.Size = new System.Drawing.Size(464, 240);
            this.gbFood.TabIndex = 2;
            this.gbFood.TabStop = false;
            this.gbFood.Text = "Food";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(324, 162);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(106, 25);
            this.label6.TabIndex = 15;
            this.label6.Text = "Ice cream";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(165, 161);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(79, 25);
            this.label5.TabIndex = 14;
            this.label5.Text = "Toaste";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(8, 161);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(76, 25);
            this.label4.TabIndex = 13;
            this.label4.Text = "Burger";
            // 
            // lbIscreamQuantity
            // 
            this.lbIscreamQuantity.AutoSize = true;
            this.lbIscreamQuantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbIscreamQuantity.Location = new System.Drawing.Point(331, 213);
            this.lbIscreamQuantity.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbIscreamQuantity.Name = "lbIscreamQuantity";
            this.lbIscreamQuantity.Size = new System.Drawing.Size(69, 17);
            this.lbIscreamQuantity.TabIndex = 12;
            this.lbIscreamQuantity.Text = "Quantity";
            // 
            // lbToasteStockQuantity
            // 
            this.lbToasteStockQuantity.AutoSize = true;
            this.lbToasteStockQuantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbToasteStockQuantity.Location = new System.Drawing.Point(175, 215);
            this.lbToasteStockQuantity.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbToasteStockQuantity.Name = "lbToasteStockQuantity";
            this.lbToasteStockQuantity.Size = new System.Drawing.Size(69, 17);
            this.lbToasteStockQuantity.TabIndex = 11;
            this.lbToasteStockQuantity.Text = "Quantity";
            // 
            // lbBurgerQunatity
            // 
            this.lbBurgerQunatity.AutoSize = true;
            this.lbBurgerQunatity.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbBurgerQunatity.Location = new System.Drawing.Point(19, 214);
            this.lbBurgerQunatity.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbBurgerQunatity.Name = "lbBurgerQunatity";
            this.lbBurgerQunatity.Size = new System.Drawing.Size(69, 17);
            this.lbBurgerQunatity.TabIndex = 10;
            this.lbBurgerQunatity.Text = "Quantity";
            // 
            // lbToastePrice
            // 
            this.lbToastePrice.AutoSize = true;
            this.lbToastePrice.Location = new System.Drawing.Point(181, 188);
            this.lbToastePrice.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbToastePrice.Name = "lbToastePrice";
            this.lbToastePrice.Size = new System.Drawing.Size(36, 25);
            this.lbToastePrice.TabIndex = 4;
            this.lbToastePrice.Text = "7€";
            // 
            // lbBurgerPrice
            // 
            this.lbBurgerPrice.AutoSize = true;
            this.lbBurgerPrice.ForeColor = System.Drawing.Color.Black;
            this.lbBurgerPrice.Location = new System.Drawing.Point(23, 188);
            this.lbBurgerPrice.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbBurgerPrice.Name = "lbBurgerPrice";
            this.lbBurgerPrice.Size = new System.Drawing.Size(48, 25);
            this.lbBurgerPrice.TabIndex = 3;
            this.lbBurgerPrice.Text = "10€";
            // 
            // lbIce_CreamPrice
            // 
            this.lbIce_CreamPrice.AutoSize = true;
            this.lbIce_CreamPrice.Location = new System.Drawing.Point(344, 188);
            this.lbIce_CreamPrice.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbIce_CreamPrice.Name = "lbIce_CreamPrice";
            this.lbIce_CreamPrice.Size = new System.Drawing.Size(36, 25);
            this.lbIce_CreamPrice.TabIndex = 5;
            this.lbIce_CreamPrice.Text = "5€";
            // 
            // pbIceCream
            // 
            this.pbIceCream.BackColor = System.Drawing.Color.White;
            this.pbIceCream.BackgroundImage = global::FoodShop.Properties.Resources.ice_cream_png_ice_cream_png_transparent_image_1574;
            this.pbIceCream.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbIceCream.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbIceCream.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbIceCream.Location = new System.Drawing.Point(327, 36);
            this.pbIceCream.Margin = new System.Windows.Forms.Padding(4);
            this.pbIceCream.Name = "pbIceCream";
            this.pbIceCream.Size = new System.Drawing.Size(137, 126);
            this.pbIceCream.TabIndex = 2;
            this.pbIceCream.TabStop = false;
            this.pbIceCream.Click += new System.EventHandler(this.pbIceCream_Click);
            // 
            // pbToaste
            // 
            this.pbToaste.BackgroundImage = global::FoodShop.Properties.Resources.images__1_;
            this.pbToaste.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbToaste.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbToaste.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbToaste.Location = new System.Drawing.Point(157, 33);
            this.pbToaste.Margin = new System.Windows.Forms.Padding(4);
            this.pbToaste.Name = "pbToaste";
            this.pbToaste.Size = new System.Drawing.Size(149, 126);
            this.pbToaste.TabIndex = 1;
            this.pbToaste.TabStop = false;
            this.pbToaste.Click += new System.EventHandler(this.pbToaste_Click);
            // 
            // pbBurger
            // 
            this.pbBurger.BackColor = System.Drawing.Color.White;
            this.pbBurger.BackgroundImage = global::FoodShop.Properties.Resources.burger_png_png_images_yellow_images_12;
            this.pbBurger.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbBurger.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbBurger.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbBurger.Location = new System.Drawing.Point(5, 31);
            this.pbBurger.Margin = new System.Windows.Forms.Padding(4);
            this.pbBurger.Name = "pbBurger";
            this.pbBurger.Size = new System.Drawing.Size(141, 126);
            this.pbBurger.TabIndex = 0;
            this.pbBurger.TabStop = false;
            this.pbBurger.Click += new System.EventHandler(this.pbBurger_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.btnClose);
            this.groupBox6.Controls.Add(this.gbFood);
            this.groupBox6.Controls.Add(this.gbDrinks);
            this.groupBox6.Controls.Add(this.label2);
            this.groupBox6.Controls.Add(this.lbPurchaseStatus);
            this.groupBox6.Controls.Add(this.lbVisitorName);
            this.groupBox6.Controls.Add(this.groupBox4);
            this.groupBox6.Controls.Add(this.btnScan);
            this.groupBox6.Controls.Add(this.gbSouvenirs);
            this.groupBox6.Controls.Add(this.btnSouvenirs);
            this.groupBox6.Controls.Add(this.btnDrinks);
            this.groupBox6.Controls.Add(this.btnFood);
            this.groupBox6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox6.Location = new System.Drawing.Point(3, 1);
            this.groupBox6.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox6.Size = new System.Drawing.Size(508, 683);
            this.groupBox6.TabIndex = 8;
            this.groupBox6.TabStop = false;
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnClose.BackgroundImage = global::FoodShop.Properties.Resources.button_x1;
            this.btnClose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnClose.Location = new System.Drawing.Point(453, 0);
            this.btnClose.Margin = new System.Windows.Forms.Padding(4);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(55, 39);
            this.btnClose.TabIndex = 12;
            this.btnClose.TabStop = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // gbDrinks
            // 
            this.gbDrinks.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.gbDrinks.Controls.Add(this.label14);
            this.gbDrinks.Controls.Add(this.label13);
            this.gbDrinks.Controls.Add(this.label12);
            this.gbDrinks.Controls.Add(this.lbWijnQuantity);
            this.gbDrinks.Controls.Add(this.lbDrinkQuantity);
            this.gbDrinks.Controls.Add(this.lbWijnPrice);
            this.gbDrinks.Controls.Add(this.lbDrinksPrice);
            this.gbDrinks.Controls.Add(this.lbBeerPrice);
            this.gbDrinks.Controls.Add(this.lbBeerQuantity);
            this.gbDrinks.Controls.Add(this.groupBox3);
            this.gbDrinks.Controls.Add(this.pbWijn);
            this.gbDrinks.Controls.Add(this.pbSoftDrinks);
            this.gbDrinks.Controls.Add(this.pbBeer);
            this.gbDrinks.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbDrinks.Location = new System.Drawing.Point(20, 187);
            this.gbDrinks.Margin = new System.Windows.Forms.Padding(4);
            this.gbDrinks.Name = "gbDrinks";
            this.gbDrinks.Padding = new System.Windows.Forms.Padding(4);
            this.gbDrinks.Size = new System.Drawing.Size(457, 244);
            this.gbDrinks.TabIndex = 0;
            this.gbDrinks.TabStop = false;
            this.gbDrinks.Text = "Drinks";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(341, 167);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(55, 25);
            this.label14.TabIndex = 16;
            this.label14.Text = "Wijn";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(168, 167);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(112, 25);
            this.label13.TabIndex = 15;
            this.label13.Text = "SoftDrinks";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(10, 167);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(57, 25);
            this.label12.TabIndex = 14;
            this.label12.Text = "Beer";
            // 
            // lbWijnQuantity
            // 
            this.lbWijnQuantity.AutoSize = true;
            this.lbWijnQuantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbWijnQuantity.Location = new System.Drawing.Point(340, 218);
            this.lbWijnQuantity.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbWijnQuantity.Name = "lbWijnQuantity";
            this.lbWijnQuantity.Size = new System.Drawing.Size(69, 17);
            this.lbWijnQuantity.TabIndex = 9;
            this.lbWijnQuantity.Text = "Quantity";
            // 
            // lbDrinkQuantity
            // 
            this.lbDrinkQuantity.AutoSize = true;
            this.lbDrinkQuantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDrinkQuantity.Location = new System.Drawing.Point(181, 219);
            this.lbDrinkQuantity.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbDrinkQuantity.Name = "lbDrinkQuantity";
            this.lbDrinkQuantity.Size = new System.Drawing.Size(69, 17);
            this.lbDrinkQuantity.TabIndex = 8;
            this.lbDrinkQuantity.Text = "Quantity";
            // 
            // lbWijnPrice
            // 
            this.lbWijnPrice.AutoSize = true;
            this.lbWijnPrice.Location = new System.Drawing.Point(348, 193);
            this.lbWijnPrice.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbWijnPrice.Name = "lbWijnPrice";
            this.lbWijnPrice.Size = new System.Drawing.Size(48, 25);
            this.lbWijnPrice.TabIndex = 6;
            this.lbWijnPrice.Text = "10€";
            // 
            // lbDrinksPrice
            // 
            this.lbDrinksPrice.AutoSize = true;
            this.lbDrinksPrice.Location = new System.Drawing.Point(199, 194);
            this.lbDrinksPrice.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbDrinksPrice.Name = "lbDrinksPrice";
            this.lbDrinksPrice.Size = new System.Drawing.Size(36, 25);
            this.lbDrinksPrice.TabIndex = 5;
            this.lbDrinksPrice.Text = "3€";
            // 
            // lbBeerPrice
            // 
            this.lbBeerPrice.AutoSize = true;
            this.lbBeerPrice.Location = new System.Drawing.Point(23, 194);
            this.lbBeerPrice.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbBeerPrice.Name = "lbBeerPrice";
            this.lbBeerPrice.Size = new System.Drawing.Size(36, 25);
            this.lbBeerPrice.TabIndex = 4;
            this.lbBeerPrice.Text = "5€";
            // 
            // lbBeerQuantity
            // 
            this.lbBeerQuantity.AutoSize = true;
            this.lbBeerQuantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbBeerQuantity.Location = new System.Drawing.Point(8, 219);
            this.lbBeerQuantity.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbBeerQuantity.Name = "lbBeerQuantity";
            this.lbBeerQuantity.Size = new System.Drawing.Size(69, 17);
            this.lbBeerQuantity.TabIndex = 7;
            this.lbBeerQuantity.Text = "Quantity";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.pictureBox9);
            this.groupBox3.Controls.Add(this.pictureBox8);
            this.groupBox3.Controls.Add(this.pictureBox7);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(459, 183);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox3.Size = new System.Drawing.Size(459, 250);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Souvenirs";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(357, 71);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(42, 25);
            this.label11.TabIndex = 6;
            this.label11.Text = "2 $";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(203, 71);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(42, 25);
            this.label10.TabIndex = 5;
            this.label10.Text = "1 $";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(44, 71);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 25);
            this.label1.TabIndex = 4;
            this.label1.Text = "20 $";
            // 
            // pictureBox9
            // 
//            this.pictureBox9.BackgroundImage = global::FoodShop.Properties.Resources.magnet;
            this.pictureBox9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox9.Location = new System.Drawing.Point(316, 100);
            this.pictureBox9.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(133, 126);
            this.pictureBox9.TabIndex = 2;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackgroundImage = global::FoodShop.Properties.Resources.keychain;
            this.pictureBox8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox8.Location = new System.Drawing.Point(167, 100);
            this.pictureBox8.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(133, 126);
            this.pictureBox8.TabIndex = 1;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackgroundImage = global::FoodShop.Properties.Resources.t_shirt;
            this.pictureBox7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox7.Location = new System.Drawing.Point(8, 100);
            this.pictureBox7.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(133, 126);
            this.pictureBox7.TabIndex = 0;
            this.pictureBox7.TabStop = false;
            // 
            // pbWijn
            // 
            this.pbWijn.BackgroundImage = global::FoodShop.Properties.Resources.wijn_png_71;
            this.pbWijn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbWijn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbWijn.Location = new System.Drawing.Point(307, 31);
            this.pbWijn.Margin = new System.Windows.Forms.Padding(4);
            this.pbWijn.Name = "pbWijn";
            this.pbWijn.Size = new System.Drawing.Size(143, 126);
            this.pbWijn.TabIndex = 2;
            this.pbWijn.TabStop = false;
            this.pbWijn.Click += new System.EventHandler(this.pbXts_Click);
            // 
            // pbSoftDrinks
            // 
            this.pbSoftDrinks.BackgroundImage = global::FoodShop.Properties.Resources.cold_drink_images_png_png;
            this.pbSoftDrinks.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbSoftDrinks.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbSoftDrinks.Location = new System.Drawing.Point(157, 31);
            this.pbSoftDrinks.Margin = new System.Windows.Forms.Padding(4);
            this.pbSoftDrinks.Name = "pbSoftDrinks";
            this.pbSoftDrinks.Size = new System.Drawing.Size(142, 126);
            this.pbSoftDrinks.TabIndex = 1;
            this.pbSoftDrinks.TabStop = false;
            this.pbSoftDrinks.Click += new System.EventHandler(this.pbDrinks_Click);
            // 
            // pbBeer
            // 
            this.pbBeer.BackColor = System.Drawing.Color.White;
            this.pbBeer.BackgroundImage = global::FoodShop.Properties.Resources.beer;
            this.pbBeer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbBeer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbBeer.Location = new System.Drawing.Point(8, 31);
            this.pbBeer.Margin = new System.Windows.Forms.Padding(4);
            this.pbBeer.Name = "pbBeer";
            this.pbBeer.Size = new System.Drawing.Size(142, 126);
            this.pbBeer.TabIndex = 0;
            this.pbBeer.TabStop = false;
            this.pbBeer.Click += new System.EventHandler(this.pbBeer_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(127, 17);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(248, 20);
            this.label2.TabIndex = 12;
            this.label2.Text = "Please Scan your RFID here";
            // 
            // lbPurchaseStatus
            // 
            this.lbPurchaseStatus.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.lbPurchaseStatus.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lbPurchaseStatus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbPurchaseStatus.ForeColor = System.Drawing.Color.White;
            this.lbPurchaseStatus.Location = new System.Drawing.Point(4, 649);
            this.lbPurchaseStatus.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbPurchaseStatus.Name = "lbPurchaseStatus";
            this.lbPurchaseStatus.Size = new System.Drawing.Size(500, 30);
            this.lbPurchaseStatus.TabIndex = 11;
            this.lbPurchaseStatus.Text = "PurchaseStatus";
            this.lbPurchaseStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbVisitorName
            // 
            this.lbVisitorName.AutoSize = true;
            this.lbVisitorName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbVisitorName.ForeColor = System.Drawing.Color.White;
            this.lbVisitorName.Location = new System.Drawing.Point(172, 116);
            this.lbVisitorName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbVisitorName.Name = "lbVisitorName";
            this.lbVisitorName.Size = new System.Drawing.Size(0, 25);
            this.lbVisitorName.TabIndex = 9;
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.White;
            this.groupBox4.Controls.Add(this.lbTotalPrice);
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Controls.Add(this.btnSell);
            this.groupBox4.Controls.Add(this.btnRemove);
            this.groupBox4.Controls.Add(this.lbReceipt);
            this.groupBox4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(14, 444);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox4.Size = new System.Drawing.Size(464, 194);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            // 
            // lbTotalPrice
            // 
            this.lbTotalPrice.AutoSize = true;
            this.lbTotalPrice.Location = new System.Drawing.Point(232, 160);
            this.lbTotalPrice.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbTotalPrice.Name = "lbTotalPrice";
            this.lbTotalPrice.Size = new System.Drawing.Size(61, 25);
            this.lbTotalPrice.TabIndex = 6;
            this.lbTotalPrice.Text = "Price";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(148, 160);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(68, 25);
            this.label8.TabIndex = 5;
            this.label8.Text = "Total:";
            // 
            // btnSell
            // 
            this.btnSell.BackColor = System.Drawing.Color.Transparent;
            this.btnSell.BackgroundImage = global::FoodShop.Properties.Resources.button_order;
            this.btnSell.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSell.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSell.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSell.Location = new System.Drawing.Point(349, 155);
            this.btnSell.Margin = new System.Windows.Forms.Padding(4);
            this.btnSell.Name = "btnSell";
            this.btnSell.Size = new System.Drawing.Size(115, 39);
            this.btnSell.TabIndex = 2;
            this.btnSell.UseVisualStyleBackColor = false;
            this.btnSell.Click += new System.EventHandler(this.btnSell_Click);
            // 
            // btnRemove
            // 
            this.btnRemove.BackColor = System.Drawing.Color.Transparent;
            this.btnRemove.BackgroundImage = global::FoodShop.Properties.Resources.button_remove__2_;
            this.btnRemove.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnRemove.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRemove.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRemove.Location = new System.Drawing.Point(0, 155);
            this.btnRemove.Margin = new System.Windows.Forms.Padding(4);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(115, 39);
            this.btnRemove.TabIndex = 1;
            this.btnRemove.UseVisualStyleBackColor = false;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // lbReceipt
            // 
            this.lbReceipt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lbReceipt.FormattingEnabled = true;
            this.lbReceipt.ItemHeight = 25;
            this.lbReceipt.Location = new System.Drawing.Point(7, 12);
            this.lbReceipt.Margin = new System.Windows.Forms.Padding(4);
            this.lbReceipt.Name = "lbReceipt";
            this.lbReceipt.Size = new System.Drawing.Size(457, 25);
            this.lbReceipt.TabIndex = 0;
            // 
            // btnScan
            // 
            this.btnScan.BackgroundImage = global::FoodShop.Properties.Resources.rfidbutten;
            this.btnScan.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnScan.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnScan.Location = new System.Drawing.Point(167, 57);
            this.btnScan.Margin = new System.Windows.Forms.Padding(4);
            this.btnScan.Name = "btnScan";
            this.btnScan.Size = new System.Drawing.Size(149, 66);
            this.btnScan.TabIndex = 8;
            this.btnScan.UseVisualStyleBackColor = true;
            this.btnScan.Click += new System.EventHandler(this.btnScan_Click);
            // 
            // gbSouvenirs
            // 
            this.gbSouvenirs.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.gbSouvenirs.Controls.Add(this.label9);
            this.gbSouvenirs.Controls.Add(this.label7);
            this.gbSouvenirs.Controls.Add(this.label3);
            this.gbSouvenirs.Controls.Add(this.lbKeyChainStockQuantity);
            this.gbSouvenirs.Controls.Add(this.lbCapsStockQuantity);
            this.gbSouvenirs.Controls.Add(this.lbKeyChainPrice);
            this.gbSouvenirs.Controls.Add(this.lbCapsPrice);
            this.gbSouvenirs.Controls.Add(this.lbTshirtPrice);
            this.gbSouvenirs.Controls.Add(this.lbTShirtStockQuantity);
            this.gbSouvenirs.Controls.Add(this.btnKeyChain);
            this.gbSouvenirs.Controls.Add(this.btnCaps);
            this.gbSouvenirs.Controls.Add(this.btnTShirt);
            this.gbSouvenirs.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbSouvenirs.Location = new System.Drawing.Point(20, 194);
            this.gbSouvenirs.Margin = new System.Windows.Forms.Padding(4);
            this.gbSouvenirs.Name = "gbSouvenirs";
            this.gbSouvenirs.Padding = new System.Windows.Forms.Padding(4);
            this.gbSouvenirs.Size = new System.Drawing.Size(459, 242);
            this.gbSouvenirs.TabIndex = 10;
            this.gbSouvenirs.TabStop = false;
            this.gbSouvenirs.Text = "Souvenirs";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(331, 162);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(107, 25);
            this.label9.TabIndex = 13;
            this.label9.Text = "KeyChain";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(187, 162);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(63, 25);
            this.label7.TabIndex = 12;
            this.label7.Text = "Caps";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(8, 162);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 25);
            this.label3.TabIndex = 11;
            this.label3.Text = "T_Shirt";
            // 
            // lbKeyChainStockQuantity
            // 
            this.lbKeyChainStockQuantity.AutoSize = true;
            this.lbKeyChainStockQuantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbKeyChainStockQuantity.Location = new System.Drawing.Point(332, 220);
            this.lbKeyChainStockQuantity.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbKeyChainStockQuantity.Name = "lbKeyChainStockQuantity";
            this.lbKeyChainStockQuantity.Size = new System.Drawing.Size(69, 17);
            this.lbKeyChainStockQuantity.TabIndex = 10;
            this.lbKeyChainStockQuantity.Text = "Quantity";
            // 
            // lbCapsStockQuantity
            // 
            this.lbCapsStockQuantity.AutoSize = true;
            this.lbCapsStockQuantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCapsStockQuantity.Location = new System.Drawing.Point(172, 220);
            this.lbCapsStockQuantity.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbCapsStockQuantity.Name = "lbCapsStockQuantity";
            this.lbCapsStockQuantity.Size = new System.Drawing.Size(69, 17);
            this.lbCapsStockQuantity.TabIndex = 9;
            this.lbCapsStockQuantity.Text = "Quantity";
            // 
            // lbKeyChainPrice
            // 
            this.lbKeyChainPrice.AutoSize = true;
            this.lbKeyChainPrice.Location = new System.Drawing.Point(338, 194);
            this.lbKeyChainPrice.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbKeyChainPrice.Name = "lbKeyChainPrice";
            this.lbKeyChainPrice.Size = new System.Drawing.Size(36, 25);
            this.lbKeyChainPrice.TabIndex = 6;
            this.lbKeyChainPrice.Text = "1€";
            // 
            // lbCapsPrice
            // 
            this.lbCapsPrice.AutoSize = true;
            this.lbCapsPrice.Location = new System.Drawing.Point(199, 187);
            this.lbCapsPrice.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbCapsPrice.Name = "lbCapsPrice";
            this.lbCapsPrice.Size = new System.Drawing.Size(36, 25);
            this.lbCapsPrice.TabIndex = 5;
            this.lbCapsPrice.Text = "3€";
            // 
            // lbTshirtPrice
            // 
            this.lbTshirtPrice.AutoSize = true;
            this.lbTshirtPrice.Location = new System.Drawing.Point(23, 194);
            this.lbTshirtPrice.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbTshirtPrice.Name = "lbTshirtPrice";
            this.lbTshirtPrice.Size = new System.Drawing.Size(48, 25);
            this.lbTshirtPrice.TabIndex = 4;
            this.lbTshirtPrice.Text = "20€";
            // 
            // lbTShirtStockQuantity
            // 
            this.lbTShirtStockQuantity.AutoSize = true;
            this.lbTShirtStockQuantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTShirtStockQuantity.Location = new System.Drawing.Point(8, 220);
            this.lbTShirtStockQuantity.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbTShirtStockQuantity.Name = "lbTShirtStockQuantity";
            this.lbTShirtStockQuantity.Size = new System.Drawing.Size(69, 17);
            this.lbTShirtStockQuantity.TabIndex = 8;
            this.lbTShirtStockQuantity.Text = "Quantity";
            // 
            // btnKeyChain
            // 
            this.btnKeyChain.BackgroundImage = global::FoodShop.Properties.Resources.keychain1;
            this.btnKeyChain.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnKeyChain.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnKeyChain.Location = new System.Drawing.Point(319, 31);
            this.btnKeyChain.Margin = new System.Windows.Forms.Padding(4);
            this.btnKeyChain.Name = "btnKeyChain";
            this.btnKeyChain.Size = new System.Drawing.Size(133, 127);
            this.btnKeyChain.TabIndex = 2;
            this.btnKeyChain.UseVisualStyleBackColor = true;
            this.btnKeyChain.Click += new System.EventHandler(this.btnKeyChain_Click);
            // 
            // btnCaps
            // 
            this.btnCaps.BackgroundImage = global::FoodShop.Properties.Resources.CAPS;
            this.btnCaps.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCaps.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCaps.Location = new System.Drawing.Point(175, 31);
            this.btnCaps.Margin = new System.Windows.Forms.Padding(4);
            this.btnCaps.Name = "btnCaps";
            this.btnCaps.Size = new System.Drawing.Size(139, 127);
            this.btnCaps.TabIndex = 1;
            this.btnCaps.UseVisualStyleBackColor = true;
            this.btnCaps.Click += new System.EventHandler(this.btnWijn_Click);
            // 
            // btnTShirt
            // 
            this.btnTShirt.BackColor = System.Drawing.Color.White;
            this.btnTShirt.BackgroundImage = global::FoodShop.Properties.Resources.t_shirt;
            this.btnTShirt.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnTShirt.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnTShirt.Location = new System.Drawing.Point(3, 31);
            this.btnTShirt.Margin = new System.Windows.Forms.Padding(4);
            this.btnTShirt.Name = "btnTShirt";
            this.btnTShirt.Size = new System.Drawing.Size(165, 127);
            this.btnTShirt.TabIndex = 0;
            this.btnTShirt.UseVisualStyleBackColor = false;
            this.btnTShirt.Click += new System.EventHandler(this.btnTShirt_Click);
            // 
            // btnSouvenirs
            // 
            this.btnSouvenirs.BackColor = System.Drawing.Color.Transparent;
            this.btnSouvenirs.BackgroundImage = global::FoodShop.Properties.Resources.button_souvenirs__1_;
            this.btnSouvenirs.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSouvenirs.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSouvenirs.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSouvenirs.Location = new System.Drawing.Point(169, 146);
            this.btnSouvenirs.Margin = new System.Windows.Forms.Padding(4);
            this.btnSouvenirs.Name = "btnSouvenirs";
            this.btnSouvenirs.Size = new System.Drawing.Size(149, 39);
            this.btnSouvenirs.TabIndex = 5;
            this.btnSouvenirs.UseVisualStyleBackColor = false;
            this.btnSouvenirs.Click += new System.EventHandler(this.btnSouvenirs_Click);
            // 
            // btnDrinks
            // 
            this.btnDrinks.BackColor = System.Drawing.Color.Transparent;
            this.btnDrinks.BackgroundImage = global::FoodShop.Properties.Resources.button_drinks__1_;
            this.btnDrinks.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnDrinks.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDrinks.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnDrinks.Location = new System.Drawing.Point(329, 146);
            this.btnDrinks.Margin = new System.Windows.Forms.Padding(4);
            this.btnDrinks.Name = "btnDrinks";
            this.btnDrinks.Size = new System.Drawing.Size(149, 39);
            this.btnDrinks.TabIndex = 7;
            this.btnDrinks.UseVisualStyleBackColor = false;
            this.btnDrinks.Click += new System.EventHandler(this.btnDrinks_Click);
            // 
            // btnFood
            // 
            this.btnFood.BackColor = System.Drawing.Color.Transparent;
            this.btnFood.BackgroundImage = global::FoodShop.Properties.Resources.button_food_bank__1_;
            this.btnFood.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnFood.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFood.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnFood.Location = new System.Drawing.Point(16, 146);
            this.btnFood.Margin = new System.Windows.Forms.Padding(4);
            this.btnFood.Name = "btnFood";
            this.btnFood.Size = new System.Drawing.Size(145, 39);
            this.btnFood.TabIndex = 6;
            this.btnFood.UseVisualStyleBackColor = false;
            this.btnFood.Click += new System.EventHandler(this.btnFood_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 5000;
            this.timer1.Tick += new System.EventHandler(this.Wonditimer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(513, 684);
            this.Controls.Add(this.groupBox6);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseUp);
            this.gbFood.ResumeLayout(false);
            this.gbFood.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbIceCream)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbToaste)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbBurger)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnClose)).EndInit();
            this.gbDrinks.ResumeLayout(false);
            this.gbDrinks.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbWijn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSoftDrinks)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbBeer)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.gbSouvenirs.ResumeLayout(false);
            this.gbSouvenirs.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox gbFood;
        private System.Windows.Forms.PictureBox pbToaste;
        private System.Windows.Forms.PictureBox pbBurger;
        private System.Windows.Forms.GroupBox gbDrinks;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.PictureBox pbIceCream;
        private System.Windows.Forms.Label lbIce_CreamPrice;
        private System.Windows.Forms.Label lbToastePrice;
        private System.Windows.Forms.Label lbBurgerPrice;
        private System.Windows.Forms.PictureBox pbWijn;
        private System.Windows.Forms.PictureBox pbSoftDrinks;
        private System.Windows.Forms.PictureBox pbBeer;
        private System.Windows.Forms.Label lbWijnPrice;
        private System.Windows.Forms.Label lbDrinksPrice;
        private System.Windows.Forms.Label lbBeerPrice;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label lbTotalPrice;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnSell;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.ListBox lbReceipt;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnSouvenirs;
        private System.Windows.Forms.Button btnFood;
        private System.Windows.Forms.Button btnDrinks;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button btnScan;
        private System.Windows.Forms.Label lbVisitorName;
        private System.Windows.Forms.GroupBox gbSouvenirs;
        private System.Windows.Forms.Label lbKeyChainPrice;
        private System.Windows.Forms.Label lbCapsPrice;
        private System.Windows.Forms.Label lbTshirtPrice;
        private System.Windows.Forms.Button btnKeyChain;
        private System.Windows.Forms.Button btnCaps;
        private System.Windows.Forms.Button btnTShirt;
        private System.Windows.Forms.Label lbIscreamQuantity;
        private System.Windows.Forms.Label lbToasteStockQuantity;
        private System.Windows.Forms.Label lbBurgerQunatity;
        private System.Windows.Forms.Label lbKeyChainStockQuantity;
        private System.Windows.Forms.Label lbWijnQuantity;
        private System.Windows.Forms.Label lbDrinkQuantity;
        private System.Windows.Forms.Label lbBeerQuantity;
        private System.Windows.Forms.Label lbCapsStockQuantity;
        private System.Windows.Forms.Label lbTShirtStockQuantity;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.PictureBox btnClose;
        private System.Windows.Forms.Label lbPurchaseStatus;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
    }
}

